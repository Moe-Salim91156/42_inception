#!/bin/bash
# ⚠️  set -e: exit on any error — keeps failures visible, don't remove
set -e

# ──────────────────────────────────────────────
# Read secrets
# ⚠️  Docker secrets are mounted as files at /run/secrets/
# ──────────────────────────────────────────────
DB_PASS=$(cat /run/secrets/db_password)
WP_ADMIN_PASS=$(cat /run/secrets/credentials)

WP_PATH=/var/www/wordpress

# ──────────────────────────────────────────────
# Only run WordPress installation on first boot
# ──────────────────────────────────────────────
if [ ! -f "${WP_PATH}/wp-config.php" ]; then
    echo ">>> First boot: installing WordPress..."

    cd ${WP_PATH}

    # Download WordPress core
    wp core download --allow-root --quiet

    # Create wp-config.php
    # ⚠️  dbhost must be the SERVICE NAME from docker-compose.yml, not an IP
    #     Docker's internal DNS resolves 'mariadb' to the MariaDB container IP
    wp config create --allow-root \
        --dbname="${MYSQL_DATABASE}" \
        --dbuser="${MYSQL_USER}" \
        --dbpass="${DB_PASS}" \
        --dbhost=mariadb:3306 \
        --dbprefix=wp_

    # ──────────────────────────────────────────────
    # ⚠️  CRITICAL: Wait loop for MariaDB
    #     WordPress container often starts before MariaDB is ready
    #     Without this loop, wp core install will fail and the container crashes
    # ──────────────────────────────────────────────
    echo ">>> Waiting for MariaDB to be ready..."
    MAX_TRIES=30
    COUNT=0
    until wp db check --allow-root 2>/dev/null; do
        COUNT=$((COUNT + 1))
        if [ $COUNT -ge $MAX_TRIES ]; then
            echo "ERROR: MariaDB not ready after ${MAX_TRIES} attempts. Exiting."
            exit 1
        fi
        echo "    MariaDB not ready yet... (attempt $COUNT/$MAX_TRIES)"
        sleep 2
    done
    echo ">>> MariaDB is ready!"

    # Install WordPress
    # ⚠️  --admin_user CANNOT contain 'admin' or 'administrator' (case-insensitive)
    #     The evaluator WILL check this — it's an explicit requirement
    wp core install --allow-root \
        --url="https://${DOMAIN_NAME}" \
        --title="Inception" \
        --admin_user="${WP_ADMIN_USER}" \
        --admin_password="${WP_ADMIN_PASS}" \
        --admin_email="${WP_ADMIN_EMAIL}" \
        --skip-email

    # ──────────────────────────────────────────────
    # Create a second non-admin user
    # ⚠️  The subject requires TWO users in the DB — one admin, one regular
    # ──────────────────────────────────────────────
    wp user create --allow-root \
        "${WP_USER}" "${WP_USER_EMAIL}" \
        --role=author \
        --user_pass="${WP_USER_PASS}"

    echo ">>> WordPress installed successfully!"
    echo "    Admin user: ${WP_ADMIN_USER}"
    echo "    Regular user: ${WP_USER}"
else
    echo ">>> WordPress already configured, skipping install."
fi

# Fix permissions so nginx can read the files
chown -R www-data:www-data ${WP_PATH}

# ──────────────────────────────────────────────
# ⚠️  CRITICAL: Use 'exec' — makes php-fpm PID 1
#     -F flag = run in foreground (required, otherwise container exits immediately)
#     Without -F, php-fpm daemonizes and the container thinks it's done and stops
# ──────────────────────────────────────────────
exec php-fpm8.2 -F
